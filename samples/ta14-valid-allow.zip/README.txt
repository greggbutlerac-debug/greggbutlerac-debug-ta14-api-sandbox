TA-14 INDEPENDENT ROUTE REPLAY PACKAGE
================================================

Standard: TA-14 Independent Route Replay Standard
Version: 1.0.0
Route ID: 5b192cd5-d750-43e4-947d-ef6a783f4bc6
Original determination: ALLOW
Package created: 2026-07-14T20:06:00+00:00
Contains sensitive material: NO

PURPOSE
-------
This package preserves the route records used to evaluate, bind, commit,
execute, and verify one consequence-bearing action.

The package is designed so an outside reviewer can verify:

1. the integrity of every included file;
2. the package-manifest signature;
3. the public signing-key fingerprint;
4. the route and request identifiers;
5. the determination and its reasons;
6. the evidence index and authority state;
7. the exact action binding;
8. the commit authorization;
9. the execution correspondence;
10. the observed outcome;
11. the ordering and integrity of the hash-linked ledger.

IMPORTANT BOUNDARY
------------------
A replay package proves what records were preserved, what determination was
made, what conditions were bound, and whether the preserved execution and
outcome correspond to those records.

It does not independently guarantee that an external evidence source was
truthful unless that source was authenticated and its evidence was included
or independently retrievable.

It is not legal advice, compliance certification, safety certification,
production approval, or a warranty.

DISCLOSURE LIMITATIONS
----------------------
- None declared.

PRIVATE-KEY RULE
----------------
No private signing key is included in this package.

The file public-verification-key.json contains only the public key and its
fingerprint. It may be used by an independent verifier to validate signatures.

EXPECTED VERIFICATION
---------------------
A conforming verifier should:

1. open package-manifest.json;
2. verify every listed file digest;
3. verify the package-manifest signature;
4. verify signed route receipts;
5. verify ledger event hashes and linkage;
6. compare route IDs and dependency digests;
7. report every failure, warning, omission, or divergence.

TA-14 CANON
-----------
No admissible evidence. No admissible execution.
